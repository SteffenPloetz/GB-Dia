This folder contains images, used to explain the content of the folder `packages`.
