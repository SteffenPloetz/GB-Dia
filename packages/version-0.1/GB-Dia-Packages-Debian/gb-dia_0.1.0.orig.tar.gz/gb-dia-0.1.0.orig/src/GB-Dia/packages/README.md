This folder contains installation packages.
